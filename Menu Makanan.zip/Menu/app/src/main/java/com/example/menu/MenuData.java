package com.example.menu;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MenuData {
    private static String[] menuName = {
            "Pecel Lele",
            "Nasi Goreng Mercon",
            "Ayam Geprek Keju",
            "Kari Ayam",
            "Tahu Bulat",
            "Salad Buah",
            "Seblak Ndower"
    };

    private static String [] menuDetail = {
            "Pecel lele atau pecek lele di Indonesia adalah nama sebuah makanan khas Jawa yang terdiri dari ikan lele dan sambal tomat. Biasanya yang dimaksud adalah ikan lele yang digoreng kering dengan minyak lalu disajikan dengan sambal tomat dan lalapan. Lalapan biasa terdiri dari kemangi, kubis, mentimun, dan kacang panjang.",
            "Nasi goreng adalah sebuah makanan berupa nasi yang digoreng dan diaduk dalam minyak goreng, margarin, atau mentega. Biasanya ditambah kecap manis, bawang merah, bawang putih, asam jawa, lada dan bumbu-bumbu lainnya; seperti telur, ayam, dan kerupuk.",
            "Ayam geprek adalah makanan ayam goreng tepung khas Indonesia yang diulek atau dilumatkan bersama sambal bajak. Kini ayam geprek telah menjadi hidangan populer yang dapat ditemukan di hampir semua kota besar di Indonesia, tetapi asal mula ayam geprek berasal dari kota Yogyakarta.",
            "Kari ayam adalah hidangan umum di Asia Selatan, Asia Tenggara, serta di Caribbean (di mana makanan tersebut biasa disebut sebagai ayam kari). Kari ayam di Asia Selatan terdiri dari daging ayam yang direbus dalam bawang bombai dan saus yang berbahan dasar tomat, yang ditambahkan dengan jahe, bawang putih, cabai dan berbagai rempah-rempah, yang biasanya meliputi kunyit, jintan putih, ketumbar, kulit kayu manis, kapulaga seberang dan lain-lain. Di luar Asia Selatan, kari ayam biasanya dibuat dengan campuran rempah-rempah siap masak yakni bubuk kari.",
            "Tahu bulat adalah sebuah jajanan kaki lima berupa olahan kacang kedelai yang dibuat menjadi sebuah tahu berbentuk bulat dengan isi kopong. Biasanya, tahu bulat dijual di sebuah mobil bak terbuka dan kebanyakan dihargai Rp500 per buah.",
            "Koktail buah atau koktil adalah makanan yang dibuat dari potongan buah dan sirup, dan disajikan dingin. Walaupun namanya mirip dengan minuman beralkohol yang disebut (koktail), koktail buah sama sekali tidak dicampur atau mengandung alkohol.",
            "Seblak adalah makanan Indonesia yang dikenal berasal dari Bandung, Jawa Barat dengan cita rasa gurih dan pedas. Terbuat dari kerupuk basah yang dimasak dengan sayuran dan sumber protein seperti telur, ayam, boga bahari, atau olahan daging sapi, dan dimasak dengan kencur."
    };

    private static String[] menuHarga = {
            "Rp 15.000",
            "Rp 14.500",
            "Rp 20.000",
            "Rp 17.500",
            "Rp 500",
            "Rp 12.000",
            "Rp 10.000"
    };

    private static int[] menuImage = {
            R.drawable.pecellele,
            R.drawable.nasgor,
            R.drawable.ayamgeprek,
            R.drawable.kariayam,
            R.drawable.tahubulat,
            R.drawable.saladbuah,
            R.drawable.seblak
    };


    static ArrayList<Menu> getListData(){
        ArrayList<Menu> list = new ArrayList<>();
        for (int position = 0; position <menuName.length; position++) {
            Menu menu = new Menu();
            menu.setName(menuName[position]);
            menu.setDetail(menuDetail[position]);
            menu.setHarga(menuHarga[position]);
            menu.setPhoto(menuImage[position]);
            list.add(menu);
        }
        return list;
    }

}
