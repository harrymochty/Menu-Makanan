package com.example.menu;

public interface OnItemClickCallback {
    void onItemCLicked(Menu menu);

}
